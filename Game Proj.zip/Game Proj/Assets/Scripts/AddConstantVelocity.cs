﻿using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using UnityEngine;

public class AddConstantVelocity : MonoBehaviour
{
    // Start is called before the first frame update
    [SerializeField]
    Vector3 v3Force;

    [SerializeField]
    KeyCode keyPositive;

    [SerializeField]
    KeyCode keyNegative;

    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
            
    }

    void FixedUpdate()
    {
       
            
         if (Input.GetKey(keyPositive) && Input.GetKey(KeyCode.Space))
            GetComponent<Rigidbody>().velocity = v3Force + Physics.gravity;
         else if (Input.GetKey(keyPositive))
            GetComponent<Rigidbody>().velocity += v3Force;


        if (Input.GetKey(keyNegative))
            GetComponent<Rigidbody>().velocity -= v3Force;
    }
}
