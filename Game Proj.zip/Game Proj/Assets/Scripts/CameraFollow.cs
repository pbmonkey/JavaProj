﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraFollow : MonoBehaviour
{
    [SerializeField]
    Transform transPos;
    void Update()
    {
        transform.position = transPos.position;
    }
}
